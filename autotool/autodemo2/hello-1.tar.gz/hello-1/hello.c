#include <stdio.h>

int main()
{
    printf("hi.\n");
    return 0;
}
